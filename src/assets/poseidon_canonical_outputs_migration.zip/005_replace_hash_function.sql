begin;

-- 005_replace_hash_function.sql
-- Business-only hash for invoice lines (exclude lineage)

create or replace function schema_poseidon_tst_16_adm._hash_invoice_line(
  _row schema_poseidon_tst_16_adm.invoice_line
) returns text
language sql
immutable
as $$
  select encode(digest((
    jsonb_strip_nulls(
      to_jsonb(_row)
        - array[
            'id','creation_user','creation_date','update_user','update_date',
            'processing_message','metadata','content_hash',
            -- exclude lineage/transport
            'output_reference','batch_reference','source_type','flow_reference'
        ]
    )::text
  ), 'sha256'), 'hex');
$$;

commit;
