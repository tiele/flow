begin;

-- 001_alter_output_definition.sql
-- Add normalized columns; stop relying on encoded "reference" for semantics.
-- Keep existing columns untouched except we add 'kind' and 'env'.

alter table schema_poseidon_tst_16_adm.output_definition
  add column if not exists kind text not null default 'CANONICAL',
  add column if not exists env  text not null default 'P',
  add column if not exists created_at timestamptz not null default now();

-- If earlier iterations added provenance columns directly on output_definition,
-- and you want them gone, uncomment these drops. They are kept commented to be safe.
-- alter table schema_poseidon_tst_16_adm.output_definition drop column if exists flow_reference;
-- alter table schema_poseidon_tst_16_adm.output_definition drop column if exists source_type;
-- alter table schema_poseidon_tst_16_adm.output_definition drop column if exists run_at;
-- alter table schema_poseidon_tst_16_adm.output_definition drop column if exists selection_hash;
-- alter table schema_poseidon_tst_16_adm.output_definition drop column if exists built_by_execution_id;

commit;
