begin;

-- 002_create_canonical_output_meta.sql
-- Canonical-only metadata lives here. Recompositions/PUBLISHED have no row here.

create table if not exists schema_poseidon_tst_16_adm.canonical_output_meta (
  output_reference text primary key
    references schema_poseidon_tst_16_adm.output_definition(reference) on delete cascade,
  flow_reference  text not null,
  source_type     text not null,
  canon_date      date not null,
  env             text not null default 'P',
  created_at      timestamptz not null default now(),
  unique (flow_reference, source_type, canon_date, env)
);

create index if not exists ix_canon_meta_flow_src_date
  on schema_poseidon_tst_16_adm.canonical_output_meta (flow_reference, source_type, canon_date);

commit;
