begin;

-- 003_backfill_canonical_meta.sql
-- If old references followed the pattern: CANON|FLOW|SOURCE|YYYY-MM-DD|ENV, backfill meta.

with parsed as (
  select
    od.reference as output_reference,
    split_part(od.reference,'|',2) as flow_ref,
    split_part(od.reference,'|',3) as source_type,
    split_part(od.reference,'|',4) as date_part,
    nullif(split_part(od.reference,'|',5),'') as env_part
  from schema_poseidon_tst_16_adm.output_definition od
  where od.reference like 'CANON|%|%|____-__-__%'  -- YYYY-MM-DD
)
insert into schema_poseidon_tst_16_adm.canonical_output_meta
  (output_reference, flow_reference, source_type, canon_date, env)
select
  p.output_reference,
  p.flow_ref,
  p.source_type,
  to_date(p.date_part,'YYYY-MM-DD'),
  coalesce(p.env_part,'P')
from parsed p
on conflict (output_reference) do nothing;

commit;
