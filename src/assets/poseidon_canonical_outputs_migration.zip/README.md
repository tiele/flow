# Poseidon Canonical Outputs Migration

This pack removes the need to encode semantics in `output_definition.reference`
and introduces a clean separation between **canonical** outputs (built from flow runs)
and **recomposition** outputs (published packages built from canonicals).

## What you get

1. **Structured metadata**
   - `output_definition.kind` (`'CANONICAL'` or `'PUBLISHED'`)
   - `output_definition.env` (`'P'` or `'S'`), default `'P'`
   - New table `canonical_output_meta` holding **only** canonical-specific fields:
     `flow_reference`, `source_type`, `canon_date`, `env`.

2. **Provenance (optional)**
   - `output_build_log` to record many executions that contributed to a canonical.

3. **Writer trigger update**
   - `trg_invoice_line_after_ins` now *computes* the canonical container
     and upserts membership to `output_invoice_line` **without the app passing an output reference**.
   - The trigger also upserts a row into `canonical_output_meta` (if kind is `'CANONICAL'`).

4. **Stable content hash**
   - `_hash_invoice_line` now excludes lineage fields so content versions don't bump
     when `flow_reference`, `source_type`, or `output_reference` change.

5. **Safer linkage**
   - Ensures the composite FK on `(line_reference, line_version_no)` from `output_invoice_line`
     to `invoice_line_version` is in place.

## Order to run

Run the files in numeric order:

1. `001_alter_output_definition.sql`
2. `002_create_canonical_output_meta.sql`
3. `003_backfill_canonical_meta.sql`
4. `004_fix_output_invoice_line_fk.sql`
5. `005_replace_hash_function.sql`
6. `006_replace_writer_trigger.sql`

Each script is self-contained and wrapped in a transaction.

## Notes

- **Recomposition outputs** (future feature):
  - Create a row in `output_definition` with `kind='PUBLISHED'` (no row in `canonical_output_meta`).
  - Fill `output_invoice_line` by copying memberships from the source canonical(s).
  - You can describe recompositions using your `rule_definition_*` tables; no schema change needed.

- **Canonical uniqueness**:
  - Canonicals are uniquely identified by `(flow_reference, source_type, canon_date, env)`;
    this is enforced in `canonical_output_meta`.

- **Backward compatibility**:
  - If you previously encoded semantics in `output_definition.reference`, we **backfill**
    the new `canonical_output_meta` table using the `CANON|FLOW|SOURCE|YYYY-MM-DD|ENV` pattern, when present.
  - Your application can now set `invoice_line.output_reference = NULL` and (optionally) set `invoice_line.environment`
    to `'P'` or `'S'`. The DB will compute everything else.

---

Generated: 2025-09-01T20:44:21.189969
