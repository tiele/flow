begin;

-- 006_replace_writer_trigger.sql
-- Trigger computes canonical container, upserts canonical meta, and maintains membership.

create or replace function schema_poseidon_tst_16_adm.make_canonical_ref(
  p_flow text, p_source text, p_date date, p_env text default 'P'
) returns text language sql immutable as $$
  select 'CANON|'||p_flow||'|'||p_source||'|'||to_char(p_date,'YYYY-MM-DD')||'|'||coalesce(p_env,'P')
$$;

create or replace function schema_poseidon_tst_16_adm.trg_invoice_line_after_ins()
returns trigger
language plpgsql
as $$
declare
  v_ver        int;
  v_line_hash  text;
  v_canon_date date;
  v_env        text;
  v_canon_ref  text;
  v_closed     bool;
begin
  -- 1) Compute business-only hash
  v_line_hash := schema_poseidon_tst_16_adm._hash_invoice_line(NEW);

  -- 2) Try find existing version (same ref + same content)
  select line_version_no
    into v_ver
  from schema_poseidon_tst_16_adm.invoice_line_version
  where reference    = NEW.reference
    and content_hash = v_line_hash
  order by line_version_no desc
  limit 1;

  -- 3) Insert/bump version when needed
  if v_ver is null then
    v_ver := coalesce(
      NEW.line_version_no,
      (select coalesce(max(line_version_no),0)+1 from schema_poseidon_tst_16_adm.invoice_line_version where reference = NEW.reference)
    );

    insert into schema_poseidon_tst_16_adm.invoice_line_version
    (
      id, creation_user, creation_date, update_user, update_date,
      reference, batch_reference, source_type, flow_reference, output_reference,
      provider_org_unit, extraction_timestamp, business_timestamp,
      billing_code_provider, billing_code_consumer, production_resource,
      quantity, unit_cost, total_cost,
      cost_component_reference, cost_component_name, cost_component_type,
      description, technical_description, finance_comment,
      environment, anomalies, metadata, "function",
      invoicing_cycle_id, billing_item_type,
      line_version_no, is_active,
      billing_code_id, billing_code_description, customer_id, customer_name,
      product_name, product_group, product_domain, manual_modified_by_user_id,
      justification, processing_message, product_id, product_reference,
      valid_from, valid_to, is_current, versioning_comment, content_hash
    )
    values
    (
      NEW.id, NEW.creation_user, NEW.creation_date, NEW.update_user, NEW.update_date,
      NEW.reference, NEW.batch_reference, NEW.source_type, NEW.flow_reference, NEW.output_reference,
      NEW.provider_org_unit, NEW.extraction_timestamp, NEW.business_timestamp,
      NEW.billing_code_provider, NEW.billing_code_consumer, NEW.production_resource,
      NEW.quantity, NEW.unit_cost, NEW.total_cost, NEW.cost_component_reference,
      NEW.cost_component_name, NEW.cost_component_type, NEW.description, NEW.technical_description,
      NEW.finance_comment, NEW.environment, NEW.anomalies, NEW.metadata, NEW."function",
      NEW.invoicing_cycle_id, NEW.billing_item_type,
      v_ver, NEW.is_active,
      NEW.billing_code_id, NEW.billing_code_description, NEW.customer_id, NEW.customer_name,
      NEW.product_name, NEW.product_group, NEW.product_domain, NEW.manual_modified_by_user_id,
      NEW.justification, NEW.processing_message, NEW.product_id, NEW.product_reference,
      NEW.valid_from, NEW.valid_to, NEW.is_current, NEW.versioning_comment, v_line_hash
    )
    on conflict (reference, content_hash) do nothing;
  end if;

  -- 4) Compute canonical container attributes
  v_canon_date := coalesce(NEW.business_timestamp::date, NEW.extraction_timestamp::date, now()::date);
  v_env := case
             when NEW.environment in ('P','S') then NEW.environment
             else 'P'
           end;

  v_canon_ref := schema_poseidon_tst_16_adm.make_canonical_ref(NEW.flow_reference, NEW.source_type, v_canon_date, v_env);

  -- 5) Ensure output exists (kind='CANONICAL')
  insert into schema_poseidon_tst_16_adm.output_definition(reference, type, closed, kind, env)
  values (v_canon_ref, 'invoice_lines', false, 'CANONICAL', v_env)
  on conflict (reference) do nothing;

  -- 6) Ensure canonical meta row exists/up-to-date
  insert into schema_poseidon_tst_16_adm.canonical_output_meta (output_reference, flow_reference, source_type, canon_date, env)
  values (v_canon_ref, NEW.flow_reference, NEW.source_type, v_canon_date, v_env)
  on conflict (output_reference) do update
    set flow_reference = excluded.flow_reference,
        source_type    = excluded.source_type,
        canon_date     = excluded.canon_date,
        env            = excluded.env;

  -- 7) Guard closed canonicals
  select closed into v_closed
  from   schema_poseidon_tst_16_adm.output_definition
  where  reference = v_canon_ref;

  if coalesce(v_closed,false) then
    raise exception 'Cannot add/replace lines in closed output %', v_canon_ref;
  end if;

  -- 8) Upsert membership pointer
  insert into schema_poseidon_tst_16_adm.output_invoice_line (output_reference, line_reference, line_version_no)
  values (v_canon_ref, NEW.reference, v_ver)
  on conflict (output_reference, line_reference)
  do update set line_version_no = excluded.line_version_no;

  return null;
end;
$$;

-- Rebind trigger
drop trigger if exists invoice_line_after_ins on schema_poseidon_tst_16_adm.invoice_line;
create trigger invoice_line_after_ins
after insert on schema_poseidon_tst_16_adm.invoice_line
for each row execute function schema_poseidon_tst_16_adm.trg_invoice_line_after_ins();

commit;
