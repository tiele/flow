begin;

-- 004_fix_output_invoice_line_fk.sql
-- Ensure a single composite FK to the exact line version exists.

do $$
begin
  begin
    alter table schema_poseidon_tst_16_adm.output_invoice_line
      drop constraint if exists output_invoice_line_output_reference_fkey,
      drop constraint if exists fk_output_invoice_line_version,
      drop constraint if exists output_invoice_line_linever_fk;
  exception when undefined_object then
    null;
  end;
end $$;

alter table schema_poseidon_tst_16_adm.output_invoice_line
  add constraint output_invoice_line_output_fk
    foreign key (output_reference)
    references schema_poseidon_tst_16_adm.output_definition(reference)
    on delete cascade;

alter table schema_poseidon_tst_16_adm.output_invoice_line
  add constraint output_invoice_line_linever_fk
    foreign key (line_reference, line_version_no)
    references schema_poseidon_tst_16_adm.invoice_line_version(reference, line_version_no)
    on delete restrict;

create unique index if not exists ux_output_invoice_line_unique
  on schema_poseidon_tst_16_adm.output_invoice_line (output_reference, line_reference);

commit;
